#ifndef SW_BUILD
#define BOOST_TEST_DYN_LINK
#endif
#define BOOST_TEST_MODULE TgBot

#include <boost/test/unit_test.hpp>
